const express = require("express");
const bodyParser = require("body-parser");
const fs = require('fs');
// instantiate the app
const app = express();

// ALLOW CORS
app.use(function (req, resp, next) {
    resp.header("Access-Control-Allow-Origin", "*");
    resp.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
    resp.header("Access-Control-Allow-Headers", "*");
    next();
})

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.use(bodyParser.text());

// register the middleware for serving static pages
app.use(express.static(`${ __dirname }/public`));

app.use("/update", function(req, res, next) {

    console.log("INCOMING!");
    let content = fs.readFileSync('./template.html').toString();
    content = content.replace('{news-content}', req.body.toString());
    fs.writeFileSync('./public/index.html', content);
    console.log("input: "+req.body.toString());
    res.send("Nice time!");

});
// tell express to listen to the specified port
app.listen(8000);