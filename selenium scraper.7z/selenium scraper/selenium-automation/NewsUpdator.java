import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;


public class NewsUpdator {

    public static void main(String[] args) {
        fetchNews();
    }

    public static void fetchNews() {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\LENOVO\\IdeaProjects\\automate1\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // Get politics news from the reporter
        driver.get("https://www.thereporterethiopia.com/politics");
        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("post-content")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("post-content")));
        List<WebElement> posts = driver.findElements(By.className("post-content"));
        String allPosts = "";
        for (WebElement post : posts) {
            // concatenate the contents
            allPosts += post.getAttribute("outerHTML");
        }

        // send updated content to the server
        ajaxUpdate(allPosts);

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.close();
    }

    public static void ajaxUpdate(String content) {

        // send updated content to the server
        try {
            final URL url = new URL("http://localhost:8000/update");
            final URLConnection urlConnection = url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            urlConnection.connect();
            final OutputStream outputStream = urlConnection.getOutputStream();
            outputStream.write(content.getBytes("UTF-8"));
            outputStream.flush();
            urlConnection.getInputStream();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}