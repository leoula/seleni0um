import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTest {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\LENOVO\\IdeaProjects\\automate1\\chromedriver.exe");
        method4();
    }

    public static void method1() {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com");
        System.out.println("Page title: "+driver.getTitle());
        System.out.println("Current URL: "+driver.getCurrentUrl());
        System.out.println("Length of page sources: "+driver.getPageSource().toString().length());
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.close();
    }

    public static void method2() {
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("http://www.yahoo.com");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.navigate().to("https://www.google.com");
        driver.navigate().refresh();
        driver.navigate().back();
        driver.navigate().forward();
        driver.close();
    }

    public static void method3() {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com");
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Addis Ababa University");
        searchBox.click();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        searchBox.clear();
        driver.close();
    }


    public static void method4() {
        WebDriver driver = new ChromeDriver();
        driver.get("http://www.portal.aait.edu.et");
        WebElement username = driver.findElement(By.id("UserName"));
        username.sendKeys("ATR/0337/08");
        WebElement password = driver.findElement(By.id("Password"));
        password.sendKeys("VILLAGER");
        WebElement submit = driver.findElement(By.className("btn-success"));
        submit.click();
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.close();
    }

}
