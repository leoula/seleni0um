import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GmailAndPortal {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\LENOVO\\IdeaProjects\\automate1\\chromedriver.exe");
        checkNewPrimaryEmails();
        checkLastSemesterGrade();
    }

    public static void checkNewPrimaryEmails() {
        WebDriver driver = new ChromeDriver();
        // Navigate to gmail's login page.
        // https://accounts.google.com/signin/v2/identifier?flowName=GlifWebSignIn&flowEntry=ServiceLogin
        driver.get("http://www.gmail.com");
        // Enter email address
        WebElement username = driver.findElement(By.id("identifierId"));
        username.sendKeys("leoul0920385881@gmail.com");
        // Click next to enter password
        WebElement next = driver.findElement(By.id("identifierNext"));
        next.click();
        // wait for the password box to appear
        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type='password']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='password']")));
        // enter password
        WebElement password = driver.findElement(By.xpath("//input[@type='password']"));
        password.sendKeys("hello hello");
        // click login
        WebElement login = driver.findElement(By.id("passwordNext"));
        login.click();
        // wait for the search box to appear, that is for the email to open
        // time out after 10 seconds
        WebDriverWait waiter = new WebDriverWait(driver, 100);
        waiter.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(@title,'Inbox')]")));
        String inbox = driver.findElement(By.xpath("//a[contains(@title,'Inbox')]")).getText();
        if(inbox.indexOf("(") == -1) {
            System.out.println("No unread messages");
        } else {
            String unreadCountString = inbox.substring(inbox.indexOf("(")+1,inbox.indexOf(")"));
            System.out.println("Number of unread messages is: "+unreadCountString);
        }
        driver.close();
    }

    public static void checkLastSemesterGrade() {
        WebDriver driver = new ChromeDriver();
        // Navigate to the portal's login page
        driver.get("http://www.portal.aait.edu.et");
        WebElement username = driver.findElement(By.id("UserName"));
        // Enter user name
        username.sendKeys("ATR/8905/08");
        // Enter password
        WebElement password = driver.findElement(By.id("Password"));
        password.sendKeys("hello");
        // Click submit and login
        WebElement submit = driver.findElement(By.className("btn-success"));
        submit.click();
        WebDriverWait waiter = new WebDriverWait(driver, 1000);
        waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("ml2")));
        waiter.until(ExpectedConditions.visibilityOfElementLocated(By.id("ml2")));
        // Go to the grades page
        WebElement gradeReportLink = driver.findElement(By.id("ml2"));
        gradeReportLink.click();
        // then find the semester grade text
        // [contains(text()='Some text')]
        WebDriverWait wait = new WebDriverWait(driver, 1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//legend[text() = 'Grade Report']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//legend[text() = 'Grade Report']")));
        String pText = driver.findElements(By.xpath("//p[contains(.,'CGPA')]")).get(0).getText();
        int indexOfCGPA = pText.indexOf("CGPA");
        String gpaString = pText.substring(indexOfCGPA+7, indexOfCGPA+11);
        System.out.println("Last semester's GPA is : "+gpaString);

        driver.close();
    }

}
